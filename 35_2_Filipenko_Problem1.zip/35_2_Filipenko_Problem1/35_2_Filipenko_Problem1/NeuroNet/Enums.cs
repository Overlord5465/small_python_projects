﻿
namespace _35_2_Filipenko_Problem1.NeuroNet
{
    enum NeuronType
    {
        Hidden,
        Output
    }
    enum NetworkMode
    {
        Train,
        Test,
        Recogn
    }
    enum MemoryMode
    {
        GET,
        SET,
        INIT
    }
}
